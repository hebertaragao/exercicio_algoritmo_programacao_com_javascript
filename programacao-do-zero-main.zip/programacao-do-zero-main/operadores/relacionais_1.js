// valores literais
console.log(7 > 9);
console.log(7 >= 7);
console.log(8 < 2);
console.log(8 <= 12);
console.log(9 == 3);
console.log(9 != 5);

let a = 7;
let b = 32;

// usando variáveis
console.log(a > b);
console.log(a >= b);
console.log(a < b);
console.log(a <= b);
console.log(a == b);
console.log(a != b);