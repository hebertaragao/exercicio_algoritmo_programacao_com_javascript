let x = 10;
x = x + 6;
x = x - 1;

let y = 20;
y += 10; // y = y + 10;
y -= 2; // y = y - 2;
y *= 2; // y = y * 2;
y /= 4; // y = y / 4;
y %= 3; // y = y % 3;

console.log(x);
console.log(y);

let w = 'texto';
w += ', mais texto';
w += '!!!';

console.log(w);