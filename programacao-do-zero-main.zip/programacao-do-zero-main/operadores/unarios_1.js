let a = 1;

a = a + 1;
a += 1;
a++;
++a;

a--;
--a;

console.log(a);