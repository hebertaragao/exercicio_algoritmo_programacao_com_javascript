const hora = 23;
const saudacao = hora <= 11 ? 'Bom dia' : 'Boa tarde';
console.log(saudacao);