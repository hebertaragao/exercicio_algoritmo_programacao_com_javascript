const hora = 11;
const saudacao = hora <= 11 ? "Bom dia" : (hora <= 17 ? "Boa tarde" : "Boa noite");
console.log(saudacao);