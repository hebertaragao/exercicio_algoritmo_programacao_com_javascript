function somar(a, b, c, d) {
    return a + b + c + d;
}

console.log(somar(1, 2, 3, 4));
console.log(somar(1, 2, 3));

console.log('Fim!');