function somar(n1, n2) {
    console.log(n1 + n2);
}

function subtrair(a, b) {
    console.log(a - b);
}

somar(3, 4);
somar(31, 98);

subtrair(11, 7);
subtrair(19, 52);