let quantidade = 0;

// indeterminada de repetições
while(Math.random() < 0.97) {
    quantidade++;
}

console.log('Qtde: ' + quantidade);