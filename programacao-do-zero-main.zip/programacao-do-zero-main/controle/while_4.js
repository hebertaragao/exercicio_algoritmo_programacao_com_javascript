
let controle = 1;

while (controle <= 10) {
    console.log(controle);
    controle++;
}

console.log('Fim!');

// declaração, expressão e incremento -> Qtde determinada!