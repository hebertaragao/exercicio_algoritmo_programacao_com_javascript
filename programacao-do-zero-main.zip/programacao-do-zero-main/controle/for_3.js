// 7, 6, 5, 4, 3

for(let i = 7; i >= 3; i--) {
    console.log(i);
}

console.log('Fim!');