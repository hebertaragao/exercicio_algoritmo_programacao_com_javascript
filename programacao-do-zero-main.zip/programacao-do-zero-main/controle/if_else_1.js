const verdadeira = true;
const falsa = false;

if(verdadeira) {
    console.log('Exec...');
} else
    console.log('Não exec...');

if(falsa)
    console.log('Não exec...');
else {
    console.log('Exec...');
}