// #
// ##
// ###
// ####
// #####
// ######

// let linha = '';

// for(let i = 1; i <= 6; i++) {
//     linha += '#';
//     console.log(linha);
// }

for(let s = '#'; s != '#######'; s += '#') {
    console.log(s);
}