while (true) {
    console.log('Laço infinito!!!');
}

console.log('Fim!');