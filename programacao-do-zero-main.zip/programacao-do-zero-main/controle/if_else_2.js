const hora = 23;
let saudacao;

if(hora < 12) {
    saudacao = 'Bom dia!';
} else {
    saudacao = 'Boa tarde!';
}

console.log(saudacao);