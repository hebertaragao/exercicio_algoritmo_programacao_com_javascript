const usuario = {
    email: 'aluno@cod3r.com.br'
};

usuario.nome = 'Aluno';
usuario.senha = '123456';

console.log(usuario.email);
console.log(usuario.nome);
console.log(usuario);