// console.log é usado para exibir algo na tela do computador!
console.log('Passo #03');
console.log('Passo #01'); // mais um exemplo de console.log!
// console.log('Passo #02');

/*
 * Esse é um
 * comentário
 * de múltiplas
 * linhas!
 */
console.log('Passo #02');