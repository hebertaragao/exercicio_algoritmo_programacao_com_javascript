let idade = 31;
console.log(typeof -31);
console.log(typeof idade);

let salario = 4578.32;
console.log(typeof salario);

let estaChovendo = true // ou false
console.log(typeof estaChovendo);

console.log(typeof "Teste");
console.log(typeof 'Teste');