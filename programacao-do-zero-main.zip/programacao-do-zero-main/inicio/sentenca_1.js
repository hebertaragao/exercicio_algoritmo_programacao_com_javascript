console
    .log("Bom dia!");
console.log("Boa tarde!");
console.log("Boa noite!");